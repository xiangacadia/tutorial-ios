# Tutorial 2. Putting together a multi-view application
You are going to:
- Add images to buttons
- Add views and ViewControllers
- Transition between screens
- Record and play audio
- Change audio speed
- Create Model
- Add delegate
